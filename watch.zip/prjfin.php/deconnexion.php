<?php
include "public/header.php";
include "includes/fonction.php";

unset($_SESSION['Utilisateur']);

header("Location: index.php");

?>
