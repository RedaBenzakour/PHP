<?php
include "public/header.php";
include "includes/fonction.php";

/*if (isset($_SESSION["Utilisateur"])) {
    header("Location: index.php");

}*/


if (isset ($_POST["creeMarque"])){
    $nom = $_POST["nom"];
    $image_name = $_FILES["image"]["name"];
    $image_temp = $_FILES["image"]["tmp_name"];

    ajoutMarque($nom, $image_name);

    $image_path = upload_marque_image($image_temp, $image_name);
    if ($image_path) {
        echo "L'image a été téléchargée avec succès.";
    } else {
        echo "Une erreur s'est produite lors du téléchargement de l'image.";
    }
}

?>

<body class="container  " style="background-image: url('assets/footerWatch.jpg');">
   
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card"style="background: rgb(63,112,67);
                background: linear-gradient(0deg, rgba(63,112,67,1) 34%, rgba(42,63,46,1) 100%);">
                <h2 class="card-title">ajouter Marque</h2>
                <form method="post" enctype="multipart/form-data" >
                    <div class="form-group">
                        <label for="exampleInputEmail1">nom de la marque</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="nom">
                        <small id="emailHelp" class="form-text text-muted">votre email est unique il faut jamais le partager.</small>
                    </div>
                    <div class="mb-3">
                        <input type="file" name="image">
                    </div>
                   
                    <div class="d-grid">
                    <input type="submit" class="btn btn-primary" id="creeMarque" name="creeMarque" value="Marque">
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<div>
  <br/>
</div>

<?php
include "public/footer.php";
?>


