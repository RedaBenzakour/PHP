<!-- modifierUtilisateur.php -->
<?php

include "includes/fonction.php";
include "public/header.php";

// Vérifier si l'utilisateur est connecté en tant qu'administrateur
if (!isset($_SESSION['Utilisateur']) || $_SESSION['Utilisateur']['id_role'] != 1) {
    header("Location: login.php");
    exit();
}

$id_utilisateur = $_GET['id_utilisateur'];

$utilisateur = getUserById($id_utilisateur);

if (!$utilisateur) {
    echo "Utilisateur non trouvé.";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $email = $_POST["email"];
    $telephone = $_POST["telephone"];
    $role=$_POST["id_role"];
    $date_naissance = $_POST["date_naissance"];

    if (updateProfile($id_utilisateur, $nom, $prenom, $email, $telephone, $date_naissance)) {
        echo "Informations utilisateur mises à jour avec succès.";
    } else {
        echo "Une erreur s'est produite lors de la mise à jour des informations utilisateur.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier l'utilisateur</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Modifier l'utilisateur</h1>
        <form action="" method="post">
            <div class="form-group">
                <label for="nom">Nom :</label>
                <input type="text" id="nom" name="nom" class="form-control" value="<?= $utilisateur['nom'] ?>">
            </div>
            <div class="form-group">
                <label for="prenom">Prénom :</label>
                <input type="text" id="prenom" name="prenom" class="form-control" value="<?= $utilisateur['prenom'] ?>">
            </div>
            <?php
    if ($_SESSION['Utilisateur']['id_role'] == 1) {
        ?>
        <div class="form-group">
                <label for="role">role :</label>
                <input type="text" id="role" name="role" class="form-control" value="<?= $utilisateur['id_role'] ?>">
            </div>

    <?php
    }
    ?>
            <div class="form-group">
                <label for="email">Email :</label>
                <input type="email" id="email" name="email" class="form-control" value="<?= $utilisateur['email'] ?>">
            </div>
            <div class="form-group">
                <label for="telephone">Téléphone :</label>
                <input type="text" id="telephone" name="telephone" class="form-control" value="<?= $utilisateur['telephone'] ?>">
            </div>
            <div class="form-group">
                <label for="date_naissance">Date de naissance :</label>
                <input type="date" id="date_naissance" name="date_naissance" class="form-control" value="<?= $utilisateur['date_naissance'] ?>">
            </div>
            <button type="submit" class="btn btn-primary">Modifier</button>
        </form>
    </div>
</body>
</html>
