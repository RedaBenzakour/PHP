<?php
include "includes/fonction.php";
include "public/header.php";

if (isset($_SESSION['Utilisateur'])) {
    header("Location: index.php");

}

if (isset($_POST['creeCompte'])) {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $date_naissance = $_POST['date_naissance'];
    $telephone = $_POST['telephone'];
    $mot_de_passe = $_POST['mot_de_passe'];
    $c_mot_de_passe = $_POST['c_mot_de_passe'];

    if ($mot_de_passe === $c_mot_de_passe) {
        inscription($nom, $prenom, $email, $date_naissance, $telephone, $mot_de_passe);
    }
}
?>
<body class="container  " style="background-image: url('assets/footerWatch.jpg');">
<div class="container mt-5 " >
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card" style="background: rgb(63,112,67);
background: linear-gradient(0deg, rgba(63,112,67,1) 34%, rgba(42,63,46,1) 100%);">
                <h2 class="card-title">Inscription</h2>
                <div class="card-body" >
                    <form method="post">
                        <div class="mb-3">
                            <label for="nom" class="form-label">Nom :</label>
                            <input type="text" class="form-control" id="nom" name="nom">
                        </div>

                        <div class="mb-3">
                            <label for="prenom" class="form-label">Prenom :</label>
                            <input type="text" class="form-control" id="prenom" name="prenom">
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email :</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>

                        <div class="mb-3">
                            <label for="date_naissance" class="form-label">Date de Naissance :</label>
                            <input type="date" class="form-control" id="date_naissance" name="date_naissance">
                        </div>

                        <div class="mb-3">
                            <label for="telephone" class="form-label">Telephone :</label>
                            <input type="text" class="form-control" id="telephone" name="telephone">
                        </div>

                        <div class="mb-3">
                            <label for="mot_de_passe" class="form-label">Mot de passe :</label>
                            <input type="password" class="form-control" id="mot_de_passe" name="mot_de_passe">
                        </div>

                        <div class="mb-3">
                            <label for="c_mot_de_passe" class="form-label">Confirmer mot de passe :</label>
                            <input type="password" class="form-control" id="c_mot_de_passe" name="c_mot_de_passe">
                        </div>

                        <div class="d-grid">
                            <input type="submit" class="btn btn-primary" id="creeCompte" name="creeCompte" value="Créer Utilisateur">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<br/><br/>
</div>

<?php
include "public/footer.php";
?>

