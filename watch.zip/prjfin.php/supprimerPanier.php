<?php

include_once "./includes/fonction.php";
if (isset($_GET['id'])) {
    if (is_numeric($_GET['id'])) {
        supprimerPanier($_GET['id']);
        header("Location: panier.php");
    }
}


