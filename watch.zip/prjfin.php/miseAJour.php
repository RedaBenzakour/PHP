<?php

require_once "./includes/fonction.php";

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    if (isset($_POST['quantite']) && is_numeric($_POST['quantite'])) {
        $quantite = $_POST['quantite'];
        $id_watch = $_GET['id'];
        ajouterPanier($id_watch, $quantite);
        header("Location: panier.php");
    }
}




?>