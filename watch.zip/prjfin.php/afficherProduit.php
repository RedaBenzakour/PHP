

<?php
include "includes/fonction.php";
include "public/header.php";
?>


<?php
$id_watch = $_GET['id'] ?? null;

if ($id_watch) {
    $watch = getWatchById($id_watch);

    if ($watch) {
        ?>
        <section class="product">
            <div class="product__photo">
                <img src="<?= $watch['chemin_image'] ?? 'placeholder_image_url'; ?>" alt="<?= $watch['nom']; ?>">
            </div>
            <div class="product__info">
                <div class="title">
                    <h1><?= $watch['nom']; ?></h1>
                    <span>COD: <?= $watch['id_watch']; ?></span>
                </div>
                <div class="price">
                    $<span><?= $watch['prix']; ?></span>
                </div>
                <div class="description">
                    <h3>Description</h3>
                    <p><?= $watch['description']; ?></p>
                </div>
                
            </div>
        </section>
        <?php
    } else {
        echo "Product not found.";
    }
} else {
    echo "Product ID not provided.";
}

include "public/footer.php";
?>

</body>
</html>
