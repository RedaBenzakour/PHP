<?php
session_start();
include "./includes/config.php";

function connexion()
{
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, DB_PORT);

    if (mysqli_connect_errno()) {
        die("erreur de connction avec la DB =>" . mysqli_connect_error());
    }
    return $conn;
}

function inscription($nom, $prenom, $email, $date_naissance, $telephone, $mot_de_passe)
{
    $sql = "insert into Utilisateur(nom,prenom,email,date_naissance,telephone,mot_de_passe,id_role)
         value(?,?,?,?,?,?,?)";
    $conn = connexion();
    $statement = mysqli_prepare($conn, $sql);

    $id_role = 2;

    $mot_de_passe = password_hash($mot_de_passe, PASSWORD_DEFAULT);
    mysqli_stmt_bind_param($statement, "ssssssi", $nom, $prenom, $email, $date_naissance, $telephone, $mot_de_passe, $id_role);
    return mysqli_stmt_execute($statement);
}

function login($email, $mot_de_passe)
{
    $user = findUserByEmail($email);
    if ($user) {
        if (password_verify($mot_de_passe, $user["mot_de_passe"])) {
            unset($user['mot_de_passe']);
            $_SESSION['Utilisateur'] = $user;
            header("Location: index.php");
            return;
        }
        echo "Email or password invalid";
    } else {
        echo "Email or password invalid";
    }
}

function findUserByEmail($email)
{
    $sql = "select u.*, r.description from Utilisateur u   join Role r on u.id_role = r.id_role where email=?";
    $conn = connexion();
    $statment = mysqli_prepare($conn, $sql);

    mysqli_stmt_bind_param($statment, "s", $email);
    mysqli_stmt_execute($statment);

    $resultat = mysqli_stmt_get_result($statment);

    if (mysqli_num_rows($resultat) > 0) {

        return mysqli_fetch_assoc($resultat);
    } else {
        return false;
    }

}


function estValid($data)
{

    foreach ($data as $item) {
        if (empty($item)) {
            return false;
        }
    }
    return true;
}


function addProduit($nom, $prix, $quantite, $description, $courte_description)
{
    $sql = "insert into Watch(nom,prix,quantite,description,courte_description)
        value(?,?,?,?,?)";

    $conn = connexion();
    $statement = mysqli_prepare($conn, $sql);

    mysqli_stmt_bind_param($statement, "ssiss", $nom, $prix, $quantite, $description, $courte_description);
    mysqli_stmt_execute($statement);
    $id_watch = mysqli_insert_id($conn);
    upload($id_watch);
    return true;
}


function upload($id_watch)
{
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
        $image_name = $_FILES["image"]["name"];
        $image_tmp = $_FILES["image"]["tmp_name"];
        $image_destination = "./assets/images/" . basename($image_name);

        $image_type = strtolower(pathinfo($image_destination, PATHINFO_EXTENSION));

        if (!in_array($image_type, array("jpg", "jpeg", "png", "gif"))) {
            echo "Seules les images JPG, JPEG, PNG et GIF sont autorisées.";
            exit();
        } else {
            if (move_uploaded_file($image_tmp, $image_destination)) {
                $conn = connexion();
                $sql = "insert into Image(id_watch,chemin_image) value(?,?)";
                $statement = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($statement, "is", $id_watch, $image_destination);
                return mysqli_stmt_execute($statement);

            }
        }
    }
}

function getAllWatchs()
{
    $sql = "SELECT f.*,i.chemin_image FROM watch f LEFT JOIN Image i on f.id_watch=i.id_watch;";
    $conn = connexion();
    $resultat = mysqli_query($conn, $sql);
    $watchs = [];
    foreach ($resultat as $watch) {
        $watchs[] = $watch;
    }
    return $watchs;
}

function getWatchById($id_watch)
{
    $sql = "SELECT f.*,i.chemin_image FROM Watch f LEFT JOIN Image i on f.id_watch=i.id_watch where f.id_watch = ?";
    $conn = connexion();

    $statement = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($statement, "i", $id_watch);
    mysqli_stmt_execute($statement);

    $resultat = mysqli_stmt_get_result($statement);
    if (mysqli_num_rows($resultat) > 0) {

        return mysqli_fetch_assoc($resultat);
    } else {
        return false;
    }
}

function ajouterPanier($id_watch, $quantite)
{
    $_SESSION['Paniers'][$id_watch] = $quantite;
    
    return;
}

function supprimerPanier($id_watch)
{
    unset($_SESSION['Paniers'][$id_watch]);
}

function getAllPanier()
{
    $watchs = [];
    foreach ($_SESSION['Paniers'] as $id_watch => $quantite) {

        $watch = getWatchById($id_watch);
        if ($watch) {
            $watchs[] = [$quantite, $watch];
        } else {
            supprimerPanier($id_watch);
        }

    }

    return $watchs;
}

function ajoutMarque($marque, $chemin_image_marque)
{
    $sql = "insert into Marque (marque, chemin_image_marque) VALUES (?, ?)";
    $conn = connexion();
    $statement = mysqli_prepare($conn, $sql);
    
    mysqli_stmt_bind_param($statement, "ss", $marque, $chemin_image_marque);
    mysqli_stmt_execute($statement);
    
    return mysqli_stmt_insert_id($statement); 
}

function upload_marque_image($image_temp, $image_name)
{
    $upload_directory = "./assets/images"; 
    $destination = $upload_directory . $image_name;

    if (move_uploaded_file($image_temp, $destination)) {
        return $destination; 
    } else {
        return false; 
    }
}

function insertPayment($id_utilisateur, $quantite, $prix_total, $mode_paiement)
{
    $conn = connexion();
   
    $date_creation = date('Y-m-d');
    
    $statut = 'En attente'; 
    
    $sql = "insert into Commande (quantite, prix, statut, date_creation, id_utilisateur, mode_paiement)
            value (?,?,?,?,?,?)";
    
    $statement = mysqli_prepare($conn, $sql);
    


    mysqli_stmt_bind_param($statement, "isssis", $quantite, $prix_total, $statut, $date_creation, $id_utilisateur, $mode_paiement);
    mysqli_stmt_execute($statement);
    $id_commande = mysqli_insert_id($conn);
    return $id_commande;


}
function insertWatchCommande($id_watch, $id_commande, $quantite)
{
    
    $conn = connexion();
    $sql = "INSERT INTO WatchCommande (id_watch, id_commande, quantite) VALUES (?, ?, ?)";
    $statement = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($statement, "iii", $id_watch, $id_commande, $quantite);
    mysqli_stmt_execute($statement);
}


function getCommandesUtilisateur($id_utilisateur) {
    $conn = connexion();

    $sql = "SELECT * FROM Commande WHERE id_utilisateur = ?";
    $statement = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($statement, "i", $id_utilisateur);
    mysqli_stmt_execute($statement);

    $resultat = mysqli_stmt_get_result($statement);

    $commandes = [];

    while ($row = mysqli_fetch_assoc($resultat)) {
        $commandes[] = $row;
    }

    return $commandes;
}
function updateProfile($id_utilisateur, $nom, $prenom, $email, $telephone, $date_naissance)
{
    $conn = connexion();
    $sql = "UPDATE Utilisateur SET nom=?, prenom=?, email=?, telephone=?, date_naissance=? WHERE id_utilisateur=?";
    $statement = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($statement, "sssssi", $nom, $prenom, $email, $telephone, $date_naissance, $id_utilisateur);
    return mysqli_stmt_execute($statement);
}
function annulerCommande($id_commande)
{
    $conn = connexion();
    $sql = "UPDATE Commande SET statut='Annulee' WHERE id_commande=?";
    $statement = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($statement, "i", $id_commande);
    return mysqli_stmt_execute($statement);
}
function modifierCommande($id_commande)
{
    $conn = connexion();
    $sql = "UPDATE Commande SET statut='entraitement' WHERE id_commande=?";
    $statement = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($statement, "i", $id_commande);
    return mysqli_stmt_execute($statement);
}
function getAllUsers()
{
    $conn = connexion();
    $sql = "SELECT * FROM Utilisateur";
    $resultat = mysqli_query($conn, $sql);
    $utilisateurs = [];
    while ($row = mysqli_fetch_assoc($resultat)) {
        $utilisateurs[] = $row;
    }
    return $utilisateurs;
}

function getAllCommands()
{
    $conn = connexion();
    $sql = "SELECT * FROM Commande";
    $resultat = mysqli_query($conn, $sql);
    $commandes = [];
    while ($row = mysqli_fetch_assoc($resultat)) {
        $commandes[] = $row;
    }
    return $commandes;
}


function getUserCommands($userId) {
    global $conn; 

    $sql = "SELECT * FROM commandes WHERE id_utilisateur = ?";
    
    $stmt = $conn->prepare($sql);
    
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    
    $result = $stmt->get_result();
    
    $commands = array();
    
    while ($row = $result->fetch_assoc()) {
        $commands[] = $row;
    }
    
    $stmt->close();
    
    return $commands;
}

function getCommandsByUserId($id_utilisateur) {
    $id_utilisateur = intval($id_utilisateur);

    $commands = [];

    $sql = "SELECT * FROM table_commandes WHERE id_utilisateur = $id_utilisateur";

    $result = mysqli_query($votre_connexion, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $commands[] = $row;
        }

        mysqli_free_result($result);
    } else {
        echo "Erreur lors de l'exécution de la requête : " . mysqli_error($votre_connexion);
    }

    return $commands;
}
function getUserById($id_utilisateur)
{
    $conn = connexion();
    $sql = "SELECT * FROM Utilisateur WHERE id_utilisateur = ?";
    $statement = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($statement, "i", $id_utilisateur);
    mysqli_stmt_execute($statement);
    $resultat = mysqli_stmt_get_result($statement);
    if (mysqli_num_rows($resultat) > 0) {
        return mysqli_fetch_assoc($resultat);
    } else {
        return false;
    }
}

?>
