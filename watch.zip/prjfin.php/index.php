<?php
include "includes/fonction.php";
include "public/header.php";

$watchs = getAllWatchs();
if (!$watchs) {
    $watchs = [];
}
?>
<body class="container" style="background: rgb(63,112,67); background: linear-gradient(0deg, rgba(63,112,67,1) 34%, rgba(42,63,46,1) 100%);">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="./assets/MonLogo.png" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="./assets/MonLogo.png" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="./assets/MonLogo.png" class="d-block w-100" alt="...">
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row row-cols-1 row-cols-md-3 g-4 py-5">
            <?php foreach ($watchs as $watch) { ?>
                <div class="col">
                    <div class="card" style="background-color: rgba(0, 0, 0,0);color: white;">
                        <a href="afficherProduitA.php?id=<?= $watch['id_watch']; ?>">
                            <img width="200px" height="400px" class="card-img-top" src="<?=
                            (isset($watch["chemin_image"]) && !empty($watch["chemin_image"])) ?
                                $watch["chemin_image"] :
                                "assets/images/watch1.png";
                            ?>">
                        </a>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $watch["nom"]; ?></h5>
                            <p class="card-text"><?php echo $watch["courte_description"]; ?></p>
                        </div>
                        <div class="d-flex justify-content-around mb-5">
                            <h3> <?php echo $watch["prix"]; ?>$</h3>
                        </div>
                        <form action="./ajouterPanier.php?id=<?= $watch['id_watch']; ?>" method='post'>
                            <button type="submit" name="submit" class="btn btn-primary">Ajouter au panier</button>
                        </form>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
    <video autoplay muted loop style="position: fixed;top: 0;left: 0;width: 100%;height: 105%;object-fit: cover; z-index: -1;">
        <source src="./assets/videos/omega.mp4" type="video/mp4">
    </video>
    <div class="blur-overlay" style="position: fixed;top: 0;left: 0;width: 100%;height: 100%;background-color: rgba(0, 0, 0, 0.5);z-index: -1;"></div>
<?php
include "public/footer.php";
?>
