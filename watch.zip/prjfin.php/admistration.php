

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
    }

    .container {
        max-width: 800px;
        margin: auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        color: #333;
    }

    h2 {
        color: #555;
        margin-bottom: 10px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #ddd;
    }

    button {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 8px 16px;
        text-align: center;
        display: inline-block;
        border-radius: 4px;
        cursor: pointer;
    }

    button:hover {
        background-color: #0056b3;
    }
</style>


    <?php
    include "includes/fonction.php";
    include "public/header.php";

    // Vérifier si l'utilisateur est connecté en tant qu'administrateur
    if (!isset($_SESSION['Utilisateur']) || $_SESSION['Utilisateur']['id_role'] != 1) {
        header("Location: login.php");
        exit();
    }

    // Récupérer tous les utilisateurs
    $utilisateurs = getAllUsers();

    ?>

    <div class="container">
        <h1>Liste des utilisateurs et de leurs commandes</h1>

        <div class="utilisateurs">
            <h2>Utilisateurs</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Email</th>
                        <th>Téléphone</th>
                        <th>Date de naissance</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($utilisateurs as $utilisateur): ?>
                        <tr>
                            <td><?php echo $utilisateur['prenom'] . ' ' . $utilisateur['nom']; ?></td>
                            <td><?php echo $utilisateur['email']; ?></td>
                            <td><?php echo $utilisateur['telephone']; ?></td>
                            <td><?php echo $utilisateur['date_naissance']; ?></td>
                            <td>
                                <a href="commandeUser.php?id_utilisateur=<?php echo $utilisateur['id_utilisateur']; ?>" class="btn btn-primary"><i class="bi bi-info-square"></i></a>
                                <a href="modifierUtilisateur.php?id_utilisateur=<?php echo $utilisateur['id_utilisateur']; ?>" class="btn btn-warning"><i class="bi bi-pencil-square"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>
