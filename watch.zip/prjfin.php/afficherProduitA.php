

<?php
include "includes/fonction.php";
include "public/header.php";
$id_watch = $_GET['id'] ?? null;

if ($id_watch) {
    $watch = getWatchById($id_watch);
}
?>
  <style>
    body {
      background-image: linear-gradient(to right bottom, #b91eda, #a02ae0, #8234e5, #5d3be8, #1241eb);
      height: 100%;
      margin: 0;
      background-repeat: no-repeat;
      background-attachment: fixed;
    }
    
    main {
      max-width: 720px;
      margin: 5% auto;
    }
    
    .card {
      box-shadow: 0 6px 6px rgba(0, 0, 0, 0.3);
      transition: 200ms;
      background: #fff;
    }
    
    .card__title {
      display: flex;
      align-items: center;
      padding: 30px 40px;
    }
    
    .card__title h3 {
      flex: 0 1 200px;
      text-align: right;
      margin: 0;
      color: #252525;
      font-family: sans-serif;
      font-weight: 600;
      font-size: 20px;
      text-transform: uppercase;
    }
    
    .icon {
      flex: 1 0 10px;
      background: #115dd8;
      color: #fff;
      padding: 10px 10px;
      transition: 200ms;
    }
    
    .icon a {
      color: #fff;
    }
    
    .icon:hover {
      background: #252525;
    }
    
    .card__body {
      padding: 0 40px;
      display: flex;
      flex-flow: row no-wrap;
      margin-bottom: 25px;
    }
    
    .half {
      box-sizing: border-box;
      padding: 0 15px;
      flex: 1 0 50%;
    }
    
    .featured_text h1 {
      margin: 0;
      padding: 0;
      font-weight: 800;
      font-family: "Montserrat", sans-serif;
      font-size: 64px;
      line-height: 50px;
      color: #181e28;
    }
    
    .featured_text p.sub {
      font-family: "Montserrat", sans-serif;
      font-size: 26px;
      text-transform: uppercase;
      color: #686e77;
      font-weight: 300;
      margin-bottom: 5px;
    }
    
    .featured_text p.price {
      font-family: "Fjalla One", sans-serif;
      color: #252525;
      font-size: 26px;
    }
    
    .image {
      padding-top: 15px;
      width: 100%;
    }
    
    .image img {
      display: block;
      max-width: 100%;
      height: 100%;
    }
    
    .description {
      margin-bottom: 25px;
    }
    
    .description p {
      margin: 0;
      font-family: "Open Sans", sans-serif;
      font-weight: 300;
      line-height: 27px;
      font-size: 16px;
      color: #555;
    }
    
    span.stock {
      font-family: "Montserrat", sans-serif;
      font-weight: 600;
      color: #a1cc16;
    }
    
    .reviews .stars {
      display: inline-block;
      list-style: none;
      padding: 0;
    }
    
    .reviews .stars li {
      display: inline-block;
    }
    
    .reviews .stars li .fa {
      color: #f7c01b;
    }
    
    .reviews > span {
      font-family: "Open Sans", sans-serif;
      font-size: 14px;
      margin-left: 5px;
      color: #555;
    }
    
    .card__footer {
      padding: 30px 40px;
      display: flex;
      flex-flow: row no-wrap;
      align-items: center;
      position: relative;
    }
    
    .card__footer::before {
      content: "";
      position: absolute;
      display: block;
      top: 0;
      left: 40px;
      width: calc(100% - 40px);
      height: 3px;
      background: #115dd8;
      background: linear-gradient(to right, #115dd8 0%, #115dd8 20%, #ddd 20%, #ddd 100%);
    }
    
    .recommend {
      flex: 1 0 10px;
    }
    
    .recommend p {
      margin: 0;
      font-family: "Montserrat", sans-serif;
      text-transform: uppercase;
      font-weight: 600;
      font-size: 14px;
      color: #555;
    }
    
    .recommend h3 {
      margin: 0;
      font-size: 20px;
      font-family: "Montserrat", sans-serif;
      font-weight: 600;
      text-transform: uppercase;
      color: #115dd8;
    }
    

  </style>
</head>

<body>
  <main>
    <div class="card">
      <div class="card__title">
        <div class="icon">
          <a href="#"><i class="fa fa-arrow-left"></i></a>
        </div>
        <h3>New products</h3>
      </div>
      <div class="card__body">
        <div class="half">
          <div class="featured_text">
            <h2><?= $watch['nom'] ?? ''; ?></h2>
            <p<h4 class="sub"><?= $watch['courte_description'] ?? ''; ?></h4></p>
            <p class="price"><?= $watch['prix'] ?? ''; ?></p>
          </div>
          <div class="image">
            <img src="<?= $watch['chemin_image'] ?? 'placeholder_image_url'; ?>" alt="<?= $watch['nom'] ?? ''; ?>">
          </div>
        </div>
        <div class="half">
          <div class="description">
            <p><?= $watch['description'] ?? ''; ?></p>
          </div>
          <span class="stock"><i class="fa fa-pen"></i> In stock</span>
          <div class="reviews">
            <ul class="stars">
              <li><i class="fa fa-star"></i></li>
              <li><i class="fa fa-star"></i></li>
              <li><i class="fa fa-star"></i></li>
              <li><i class="fa fa-star"></i></li>
              <li><i class="fa fa-star-o"></i></li>
            </ul>
            <span><?= $watch['quantite'] ?? ''; ?></span>
          </div>
        </div>
      </div>
      <div class="card__footer">
        <div class="recommend">
          <p>Recommend par</p>
          <h3>Notre store</h3>
        </div>
        
      </div>
    </div>
  </main>
</body>

</html>
