<?php
require_once "./includes/fonction.php";

if (isset($_GET['id'])) {
    if (is_numeric($_GET['id'])) {
        $id_watch = $_GET['id'];
        ajouterPanier($id_watch, 1);
        header("Location: index.php");

    }
}

// process_payment.php


?>



