<?php
include "includes/fonction.php";
include "public/header.php";


if (isset($_SESSION['Utilisateur'])) {
    header("Location: index.php");

}


if (isset ($_POST['loginCompte'])){
    $email =$_POST['email'];
    $mot_de_passe =$_POST['mot_de_passe'];
    login($email, $mot_de_passe);

}
?>

<body class="container  " style="background-image: url('assets/footerWatch.jpg');">
   
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card"style="background: rgb(63,112,67);
                background: linear-gradient(0deg, rgba(63,112,67,1) 34%, rgba(42,63,46,1) 100%);">
                <h2 class="card-title">connexion</h2>
                <form method="post">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email">
                        <small id="emailHelp" class="form-text text-muted">votre email est unique il faut jamais le partager.</small>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Mot de Passe</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" name="mot_de_passe">
                    </div>
                    <div class="d-grid">
                    <input type="submit" class="btn btn-primary" id="creeProduit" name="loginCompte" value="Connection">
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<div>
  <br/>
</div>

<?php
include "public/footer.php";
?>


