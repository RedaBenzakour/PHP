<style>
    .container {
    max-width: 800px;
    margin: auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

h2 {
    color: #555;
    margin-bottom: 10px;
}

.table-container {
    overflow-x: auto;
}

.commandes-table {
    width: 100%;
    border-collapse: collapse;
}

.commandes-table th, .commandes-table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.commandes-table th {
    background-color: #f2f2f2;
}

.commandes-table tr:nth-child(even) {
    background-color: #f2f2f2;
}

.commandes-table tr:hover {
    background-color: #ddd;
}

</style>
<?php
include "includes/fonction.php";
include "public/header.php";

// Vérifier si l'ID de l'utilisateur est passé dans l'URL
if (isset($_GET['id_utilisateur'])) {
    $id_utilisateur = $_GET['id_utilisateur'];

    // Récupérer les informations de l'utilisateur
    $utilisateur = getUserById($id_utilisateur);

    // Récupérer toutes les commandes de l'utilisateur
    $commandes = getCommandesUtilisateur($id_utilisateur);

    // Si l'utilisateur n'existe pas ou s'il n'a pas de commandes, afficher un message
    if (!$utilisateur || empty($commandes)) {
        echo "<p>Aucune commande trouvée pour cet utilisateur.</p>";
    } else {
        // Traitement du formulaire d'annulation ou de modification de la commande
        if (isset($_POST['action'])) {
            $id_commande = $_POST['id_commande'];
            $action = $_POST['action'];
            if ($action === "annuler_commande") {
                annulerCommande($id_commande);
            } else if ($action === "modifier_commande") {
                modifierCommande($id_commande);
            }
        }

        // Afficher les détails de l'utilisateur
        echo "<div class='container'>";
        echo "<h1>Commandes de " . $utilisateur['prenom'] . " " . $utilisateur['nom'] . "</h1>";
        echo "<p>Email: " . $utilisateur['email'] . "</p>";
        echo "<p>Téléphone: " . $utilisateur['telephone'] . "</p>";
        echo "<p>Date de naissance: " . $utilisateur['date_naissance'] . "</p>";

        // Afficher la liste des commandes
        echo "<h2>Liste des commandes</h2>";
        echo "<div class='table-container'>";
        echo "<table class='commandes-table'>";
        echo "<tr><th>ID Commande</th><th>Quantité</th><th>Prix</th><th>Statut</th><th>Date de création</th><th>Actions</th></tr>";

        foreach ($commandes as $commande) {
            echo "<tr>";
            echo "<td>" . $commande['id_commande'] . "</td>";
            echo "<td>" . $commande['quantite'] . "</td>";
            echo "<td>" . $commande['prix'] . "</td>";
            echo "<td>" . $commande['statut'] . "</td>";
            echo "<td>" . $commande['date_creation'] . "</td>";
            echo "<td>";
            ?>
            <form method="post">
                <input type="hidden" name="id_commande" value="<?php echo $commande['id_commande']; ?>">
                <input type="hidden" name="action" value="annuler_commande">
                <button type="submit" class="btn btn-danger btn-sm"><i class="bi bi-x-square"></i></button>
            </form>
            <form method="post">
                <input type="hidden" name="id_commande" value="<?php echo $commande['id_commande']; ?>">
                <input type="hidden" name="action" value="modifier_commande">
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-pencil-square"></i></button>
            </form>
            <?php
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "</div>"; // Fermeture de la div table-container
        echo "</div>"; // Fermeture de la div container
    }
} else {
    // Si l'ID de l'utilisateur n'est pas passé dans l'URL, rediriger vers une autre page
    header("Location: index.php");
    exit();
}

include "public/footer.php";
?>
