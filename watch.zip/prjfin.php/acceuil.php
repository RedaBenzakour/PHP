<?php
include "includes/fonction.php";
include "public/header.php";
?>
<style>
    @import url('https://fonts.cdnfonts.com/css/graphik');
*
{
    margin: 0;
}
body{
    margin: 0;
    background-color: black;
    font-family: 'Graphik', sans-serif;
}

a{
    text-decoration: none;
}

    .nav       
    {
        display: flex;
        text-decoration: none;
        background-color: white;
        height: 50px;

    }
    .nv{
        color: #676767; 
    }
    .lang{
        color: #676767;
    }
    .btn-style2{
        padding-right: 14px;
        padding-left: 10px;
    }
    .icon_nav{
        width: 10px;
        height: 10px;
        color: #676767;
        padding-right: 2px;
    }

    .nav_menu{ 
        display: flex;
        justify-content: space-around;
        list-style: none; 
        font-family: sans-serif;
        top: 7px;
        color: white;
        padding-top: 1%;
        padding-left: 8px;
        margin-right: 7%; 
    }
    #searchbar{
        background-color: #e3e3e3;
        width: 300px;
        height: 20px;
        border: 1px;
        padding: 22px 0px 8px 7px ;
        margin-left: 15px;
        margin-right: 10px;
        margin-bottom: 70px;
        border-radius: 1px;
        
     }
    .search{
        margin-left: 55%;
        background-color: #e3e3e3;
    }
    .search i{
        background-color: #e3e3e3;
        padding-top: 22px;
        padding-bottom: 11px;
        padding-left: 10px;
        padding-right: 10px;
    }
    .nav1
    {
        height: 8px;
        background-color: #cc0000;
    }


#logo{
    text-align: start;
    margin-left: 80px;
    padding-right: 30px;
}
#list2 
{
    
    display: flex;
    list-style: none;
    margin-left: 34%;
    color: white;
    font-size: 1.1em;
    margin-bottom: 100px;

}


.lst{
    display: flex;
    margin-left: 4%;
    margin-top: 20px;

}

ul li
{
    
    margin-bottom: 10%;
    padding-left: 25px;
    
    
}
li a {
    color: white;
    padding-bottom: 40px;
   
    
}
.sec1
{
  
  margin: 10px;
    
}
.imt{
text-align: end;
margin-right: 60px;
border-radius: 50px;
}
.imt img{
border-radius: 8px;
}
.bl1{
    display: flex;
    justify-content: space-around;
    

}
.txt{
    color: white;
    text-align: start;
    margin-top: 9%;
    margin-left: 60px;
   
}
#t{
    font-size: 1.3em;  
    margin-right: 190px;
}
#t1{
    margin-bottom: 20px;
}
#t2{
    margin-bottom: 20px;
}
#t3{
    margin-bottom: 25px;
}



.bl1 a{
    background-color: #cc0000;
    color: white;
    margin-bottom: 20px;
    padding-top: 70px;
    padding: 10px;
    border-radius: 5px;
    font-size: 1em;
    transition: all 0.1s ease-in-out;
    cursor: pointer; 
}
.bl1 a:hover{
    background-color: #e20303;
}

.header_sec1
{
font-size: 3.5em;
padding-top: 15%;
color: white;

}
.btn_group
{
    display: flex;
    justify-content: center;
}
.btn1 a 
{
    color: white;
    
}
.btn2 a 
{
    color: white;
}
.btn1
{
    padding-top: 12px;
    border :1px; 
    border-radius: 5px;
    border-color: #0082f3;
    background-color: #0082f3;
    border-style: solid;
    width: 10%;
    height: 40px;
    margin-right: 10px;
    
}
.btn2
{
    padding-top: 12px;
    opacity: 0.7;
    border :1px; 
    border-style: solid;
    border-color: white;
    border-radius: 5px;
    width: 14%;
    height: 40px;
}




.sec2
{
    margin-top: 3%;
    margin-bottom: 3%;
}
.header_sec2
{
    color: #808080;
    font-size: 2.5em;
    text-align: center;
    margin-bottom: 4%;

}
.box
{
    display: flex;
    justify-content: space-around;
    background-color: white;
    padding: 25px 30px 27px 30px;
    margin: 95px;
    border-radius: 3px;
    
}

.box1
{
    width: 55%;
    height: 51%;
    text-align: center;
    padding-top: 25px;

}
#bx{
    width: 92px;
    height: 92px;
}

.img_box
{
width: 45px;
height: 45px;
}





.img_blk2
{
    width: 368px;
    height: 368px;
    border-radius: 5px;

    
}
.sub_block2
{
    color:black;
    text-align: start;
    background-color: white;
    padding: 30px 30px 50px 30px;
    border-radius: 5px;
    transition: all 0.1s ease-in-out;
    cursor: pointer; 
   
}
.sub_block2 a:hover{
    background-color: black;
    color: white;
}
.sub_block2 h2{
    padding-bottom: 50px;
}
.sub_block2 p{
    padding-bottom: 20px;
}
.block2
{
    display: flex;
    justify-content: space-around;
}
.btn3 
{
    
    color: black;
    border-style: solid;
    border-color: black;
    border-width: 1px;
    border-radius: 3.5px;
    padding: 8px;
    margin-bottom: 25%;
    margin-top: 20px;
    
    
}
#tlp{
  margin-bottom: 30%;
  margin-top: 20px;
}
#tld{
    margin-bottom: 30%;
    margin-top: 20px;
}
#tl{
    padding-bottom: 25%;
    margin-top: 20px;
}


.sec4{
    text-align: center;
    
}
.img_blk4{
    padding-right: 80px;
    padding-bottom: 40px;
}
.block4{
    display: flex;
    justify-content: space-around;
    background-color: #cc0000;
    border-radius: 5px;
    color: white;
    text-align: start;
    margin: 125px 90px 70px 90px;
    padding: 40px;
}
.btn4{
    color: white;
    border-style: solid;
    border-color:white;
    border-width: 3px;
    border-radius: 3.5px;
    padding: 13px 25px 13px 30px;
    margin: 15px;    
  
}
.blc{
    margin-top: 30px;
    font-size: 1.2em;
}
.blc p{
    margin-bottom: 20px;
    padding-right: 30px;
}
.blc4{
    margin-top: 50px;
    transition: all 0.1s ease-in-out;
    cursor: pointer; 

}
.blc4 a:hover{
    background-color: white;
    color: black;
}

.header_sec4{
    font-size: 1.9em;
    margin-bottom: 10px;
}


.bl5{
    display: flex;
    justify-content: space-around;
    margin-bottom: 5px;
    margin-top: 20px;

}
.txt5{
    color: white;
    text-align: start;
    margin-top: 5%;
    padding-left: 100px;
   
}
#t5{
    font-size: 1.4em;
    padding-right: 350px;
}
#tt1{
    margin-bottom: 20px;
}
#tt2{
    margin-bottom: 20px;
}
#tt3{
    margin-bottom: 25px;
}
.imt5 img{
    padding-bottom: 30px;
    margin-right: 100px;
    border-radius: 5px;
}

#ts{
    text-align: center;
    color: black;
    margin-bottom: 60px;
}
.box6{
    background-color: white;
    padding-top: 70px;
    padding-bottom: 70px;
    margin: 35px 100px 35px 100px;
    border-radius: 3px;
    transition: all 0.1s ease-in-out;
    cursor: pointer;
}
.box6 a:hover{
    background-color: black;
    color: white;
}
.bx6
{
    display: flex; 
}
.bx1
{
    width: 48%;
    height: 45%;
    text-align: center;
    padding-top: 5px;
    padding-bottom: 10px;

}
.bx1 h1 {
    padding-top: 40px;
}
.bx1 p {
    padding-top: 10px;
    padding-bottom: 30px;
}
.bx1 a {
    margin-top: 30px;
}
.btn6 
{
    color: black;
    border-style: solid;
    border-color: black;
    border-width: 2px;
    border-radius: 3.5px;
    padding: 10px 30px 10px 30px;
    margin-top: 10px; 
}
.img_box
{
width: 57px;
height: 60px;
}
.img_b{
    padding-top: 60px;
}


.section7{
    text-align: center;
    
}
.img_blk7{
    padding-right: 80px;
    padding-bottom: 40px;
}
.block7{
    display: flex;
    justify-content: space-around;
    background-color: #333;
    border-radius: 5px;
    color: white;
    text-align: start;
    margin: 10px 100px 10px 100px;
    padding: 40px 50px 40px 50px;
}
.blc7{
    margin-top: 30px;
    font-size: 1.2em;
}
.blc7 p{
    margin-bottom: 20px;
    padding-right: 70px;
}
.blc7 img{
    padding-right: 20px;
}
.blc7 h2{
    padding-right: 40px;
}
.blc8{
    padding: 8px;
    margin: 20px;
    margin-top: 30px;
    padding-left: 150px;
    transition: all 0.1s ease-in-out;
    cursor: pointer; 
}
.blc8 a:hover{
    background-color: #e20303;
}
.header_sec7{
    font-size: 1.9em;
    margin-bottom: 10px;
}
.btn7{
    color: white;
    background-color: #cc0000;
    border-width: 3px;
    border-radius: 3.5px;
    padding: 13px 25px 13px 25px;
    margin: 15px;
  
}

.footer{
   
    color: white;
    text-align: center;
    background-color: #2d2d2d;
    padding-top: 40px;
    padding-bottom: 10px;
    margin-top: 30px;
    
}
.fot{
    display: flex;
    margin-right: 60px;
    margin-left: 6%;
    padding-right: 8%;

}
.fot1 {
    display: flex;
    justify-content: space-between;
    margin-left: 10px;
}

#icon{
    margin-right: 3px;
    padding-left: 4px;
    width: 23px;
    height: 24px;
}
.icon-rese{
    margin-left: 19%; 
}
#icon-r{
    margin-left: 10px;
    padding-left: 8px;
}
.tx{
    display: flex;
    text-align: start;
    margin-left: 8%;
    margin-top: 7%;

}
.tx1{
    margin-right: 15%;
}
.tx1 p{
    padding-bottom: 10%;
}

.tl{
    display: flex;
    justify-content: space-between; 
}
.b{
    color: white;
}

.footer p{
    padding-top: 6%;
}


</style>

            <main>
                <section class="sec1">
                    <div class="lst">
                    <div class="bl1">
                        <div class="txt">
                            <div id="t">
                            <h4 id="t1">My .</h2>
                            <h1 id="t2">Immigration,Nous construisons des sourires.</h1>
                            <h5 id="t3"> Avec DREAM WAYS obtenez vos bons plans.</h3>
                            <a href="index_connexion.html" id="inf">bienvenue</a>
                        </div>
                        </div>
                    <div class="imt">
                        <img src="image/accueil_avion.png">
                    </div>
                </div>
                </div>
                </section>
                <section class="sec2">
                    <div class="box">
                        <div class="box1">
                            <a  class=""href=""><img class="img_box" src="icones/famille.png" alt="" id="bx"></a>
                            <p>famille</p>
                        </div>
                        <div class="box1">
                            <a  class=""href=""><img class="img_box" src="icones/etudiant.png" alt="" id="bx"></a>
                            <p>etudiant</p>
                        </div>
                         <div class="box1">
                            <a  class=""href=""><img class="img_box" src="icones/travailleur.png" alt="" id="bx"></a>
                            <p>travailleur</p>
                        </div>
                        <div class="box1">
                            <a  class=""href=""><img class="img_box" src="icones/visiteur.png" alt="" id="bx"></a>
                            <p>visiteur</p>
                        </div>
                      
                    </div>
                </section>
                <section class="sec3">
                    <div class="block2">
                        <div class="sub_block2">
                            <img class="img_blk2"src="image/avocat1.jpeg" alt="">
                            <h2 id="tlp">venez pour une consultation.<br>notre avocat frederick</h2>
                            <p>expert dans tous les types de dossiers.</p>
                        </div>
                        <div class="sub_block2">
                            <img class="img_blk2"src="image/consultante.jpeg" alt="">
                            <h2 id="tl"><br>venez pour votre avenir.<br>notre consultante yana</h2>
                            <p>suivi en temps reel de votre dossier</p>
                        </div>
                        <div class="sub_block2">
                            <img class="img_blk2"src="image/exemple-etudiant.jpg" alt="">
                            <h2 id="tld">exemple-etudiant <br>notre premier dossier hasan.</h2>
                            <p>Je recommande vivement ce bureau d'immigration.</p>
                        </div>
                    </div>
                </section>
                <section class="sec4">
                    <div class="block4">
                    <img class="img_blk4"src="icones/information.jpeg" alt="">
                    <div class="blc">
                    <h2 class="header_sec4">information surcabine</h2>
                    <P>Le cabinet d’immigration ma vie au Canada travaille exclusivement avec des consultants en immigration réglementés du Canada  qui 
                        sont membres en règle du Collège des consultants en immigration et en citoyenneté .</P>
                    </div>
                        <div class="blc4">
                        
                        <a ><h3>notre histoire</h3></a>
                    </div>
                </div>
            </section>
                <section class="section5">
                <div class="bl5">
                    <div class="txt5">
                        <div id="t5">
                        <h1 id="tt1">On Vous Suivi Dans Vos REVE De Future.</h1>
                        <h2 id="tt3">Nos reve sont Vos reve!</h2>
                    </div>
                    </div>
                <div class="imt5">
                    <img src="image/immigration.jpg">
                </div>
                
            </div>
            </div>
                </section>
                <section class="section6">
                    <div class="box6">
                        <div><p>
                            <button>ici</button>
                            <address style="position:relative ; fixed:initial ;">
                                <img class="id_image_reda" src="image/techno_all.jpeg">

                                <img class="id_image_reda" src="image/techno_all.jpeg">
                            </address>
                        </p></div>
                        <h2 id="ts">POURQUOI NOUS?</h2>  
                        <div class="bx6">                    
                        <div class="bx1">
                            <img class="img_b" src="icones/rejoindre.jpg" alt="" >
                            <h1>Rapiditet du tretement dossier<br>
                                    Grace a notre<br> experience<h1>
                            <a  class="btn6" href="http://">rejoindre</a>
                        </div>
                        <div class="bx1">
                            <img class="img_b" src="icones/dire.jpg" alt="" >
                            <h1>Service personnel et professionel <br>
                                Dite!<br>c'est deja Fait.</h1>
                            <p></p>
                            <a  class="btn6" href="https://">action</a>
                        </div>
                         <div class="bx1">
                            <img class="img_b" src="icones/red-hearts.svg" alt="" >
                            <h1>suivi personnel de nos immigrant<br>
                                c'est un bon choix <br>pour vous.<br></h1>
                            <p></p>
                            <a  class="btn6" href="https://">savoir</a>
                        </div>
                    </div>
                </div>
                </section>
                <section class="section7">
                    <div class="block7">
                    <img class="img_blk7"src="icones/red-circle-white-enveloppe-no-shadow.svg" alt="">
                    <div class="blc7">
                    <h2 class="header_sec7">des bons plan pour vous! <br> ce passe ici.</h2>
                    <p>il vous souffi juste d'inscrire a notre page est on commence!!!.</p>
                    </div>
                        <div class="blc8">
                        <a  class="btn7"href="https://www.virginplus.ca/en/hot-offers/email-sign-up.html">M'inscrire</a>
                    </div>
                </div>
            </section>
            </main>
        <footer class="footer">
            <div class="fot">                    
                <div class="fot1">
                    <img src="icones/footer-login-red.png" alt="" id="icon">
                    <a  class="b"href="http://">Connexion</a>
                </div>
                <div class="fot1">
                    <img  src="icones/footer-find-a-store-red.png" alt="" id="icon">
                    <a  class="b"href="http://">Ville</a>
                </div>
                 <div class="fot1">
                    <img src="icones/footer-contact-us-red.png" alt="" id="icon">
                    <a  class="b"href="http://">A Propos</a>
                </div>
                <div class="fot1">
                    <img src="icones/footer-email-red.png" alt="" id="icon">
                    <a  class="b"href="http://">CONTACT</a>
                </div>
                <div class="fot1">
                    <img src="icones/footer-feedback-red.png" alt="" id="icon">
                    <a  class="b"href="http://">DESCRIPTION</a>
                </div>
                <div class="icon-rese">
                <a  class=""href="https://www.facebook.com/virginplus"><img src="icones/footer-grey-circle-facebook.png" alt="" id="icon-r"></a>
                <a  class=""href="https://www.instagram.com/virginplus/"><img src="icones/footer-grey-circle-instagram.png" alt="" id="icon-r"></a>
                <a  class=""href="https://twitter.com/virginplus"><img src="icones/footer-grey-circle-twitter.png" alt="" id="icon-r"></a>
                <a  class=""href="https://www.youtube.com/virginplus"><img src="icones/footer-grey-circle-youtube.png" alt="" id="icon-r"></a>
            </div>
            </div>
        </div>
        <div class="tx">                    
            <div class="tx1">
                <p>POURQUOI dreamways</p>
                <p>meilleur offre</p>
                <p>vous voulez inscrire?</p>
            </div>
            <div class="tx1">
                <p>consultation</p>
                <p>offre</p> 
            </div>
             <div class="tx1">
                <p>Activate </p>
                <p>Nous Trouver</p>
                <p>MONTREAL</p>
                <p>reservation</p>
            </div>
            <div class="tx1">
                <p>regle</p>
                <p>CONTACT</p>
                <p>Accessibilite</p>
            </div>
            </div>
            <p>© DreamWays.ll rights reserved. Developed By IT CARES MONTREAL .</p>
           
        </footer>
    </body>
</html>