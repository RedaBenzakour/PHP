-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 23 avr. 2024 à 01:55
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `mywatch`
--

-- --------------------------------------------------------

--
-- Structure de la table `adresse`
--

CREATE TABLE `adresse` (
  `id_adresse` int(11) NOT NULL,
  `rue` varchar(100) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `code_postal` varchar(10) NOT NULL,
  `province` varchar(100) NOT NULL,
  `defaut` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `adresseutilisateur`
--

CREATE TABLE `adresseutilisateur` (
  `id_utilisateur` int(11) DEFAULT NULL,
  `id_adresse` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `id_commande` int(11) NOT NULL,
  `quantite` int(11) DEFAULT NULL,
  `prix` varchar(10) DEFAULT NULL,
  `statut` varchar(50) DEFAULT NULL,
  `date_creation` date DEFAULT NULL,
  `id_utilisateur` int(11) DEFAULT NULL,
  `mode_paiement` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id_commande`, `quantite`, `prix`, `statut`, `date_creation`, `id_utilisateur`, `mode_paiement`) VALUES
(85, 3, '124650', 'En attente', '2024-04-17', 4, 'attent'),
(86, 2, '61800', 'En attente', '2024-04-17', 4, 'attent'),
(87, 1, '38500', 'En attente', '2024-04-17', 6, 'attent'),
(88, 2, '136100', 'En attente', '2024-04-17', 6, 'attent'),
(89, 1, '38500', 'En attente', '2024-04-17', 6, 'attente'),
(90, 1, '38500', 'En attente', '2024-04-17', 6, 'attent'),
(91, 12, '118650', 'Annulee', '2024-04-19', 5, 'attent'),
(92, 9, '415600', 'Annulee', '2024-04-19', 5, 'attent'),
(93, 3, '87500', 'Annulee', '2024-04-23', 5, 'attent');

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

CREATE TABLE `image` (
  `id_image` int(11) NOT NULL,
  `id_watch` int(11) DEFAULT NULL,
  `chemin_image` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `image`
--

INSERT INTO `image` (`id_image`, `id_watch`, `chemin_image`) VALUES
(2, 12, './assets/imagesScreenshot 2024-03-24 103521.png'),
(3, 13, './assets/imagesScreenshot 2024-03-24 103539.png'),
(4, 15, './assets/imagesScreenshot 2024-03-24 103701.png'),
(5, 16, './assets/imagesScreenshot 2024-03-24 103608.png'),
(6, 17, './assets/imagesScreenshot 2024-03-24 103622.png'),
(7, 18, './assets/imagesScreenshot 2024-03-24 103635.png'),
(8, 19, './assets/imagesScreenshot 2024-03-24 103647.png'),
(9, 20, './assets/imagesScreenshot 2024-03-24 103701.png'),
(10, 21, './assets/imagesScreenshot 2024-03-24 103803.png');

-- --------------------------------------------------------

--
-- Structure de la table `marque`
--

CREATE TABLE `marque` (
  `id_marque` int(11) NOT NULL,
  `marque` text DEFAULT NULL,
  `chemin_image_marque` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `marque`
--

INSERT INTO `marque` (`id_marque`, `marque`, `chemin_image_marque`) VALUES
(1, 'rolex', 'rolex-logo.png'),
(13, 'hublot', 'Hublot-Logo.png');

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `id_role` int(11) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`id_role`, `description`) VALUES
(1, 'admin'),
(2, 'client');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id_utilisateur` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `date_naissance` date DEFAULT NULL,
  `id_role` int(11) DEFAULT NULL,
  `mot_de_passe` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_utilisateur`, `nom`, `prenom`, `email`, `telephone`, `date_naissance`, `id_role`, `mot_de_passe`) VALUES
(4, 'benzakour', 'reda', 'redabenzakour203@gmail.com', '14388602003', '2024-02-28', 1, '$2y$10$cO9b3nn90MpRLcOGtjgYZuj7Rh3u5/cmJx5onvNBtz8xpPAopSbAq'),
(5, 'imane', 'bellghzal', 'imane@gmail.com', '14388602003', '2024-04-17', 2, '$2y$10$Ec8reCmls/l1bxjqWHpYTO8UHQWfSv32K6M5E97nI0Ysl52NMs0EK'),
(6, 'benouar', 'ayoub', 'ayoubbenouar@gmail.com', '5140005689', '2001-02-06', 1, '$2y$10$BKWUSARsOjvq55Y6k9Noj.JEKfzNmBZMf4X9ok2x1hOmexw/FafOu');

-- --------------------------------------------------------

--
-- Structure de la table `watch`
--

CREATE TABLE `watch` (
  `id_watch` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prix` varchar(10) NOT NULL,
  `description` text DEFAULT NULL,
  `courte_description` varchar(255) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `watch`
--

INSERT INTO `watch` (`id_watch`, `nom`, `prix`, `description`, `courte_description`, `quantite`) VALUES
(12, 'DateJust', '38500', 'Cette Oyster Perpetual Datejust 31 en or jaune 18 ct est dotée d’un cadran blanc et d’un bracelet President.', 'Faire date', 154),
(13, 'Submariner', '11700', 'Acier Oystersteel est dotée d’un disque de lunette Cerachrom en céramique noire et d’un cadran noir, ainsi que de grands index luminescents.', 'Profonde confiance', 210),
(15, 'GMT-Master ||', '15700', 'L’Oyster Perpetual GMT-Master II en Acier Oystersteel est dotée d’un cadran noir et d’un bracelet Jubilee.', 'Le temps des liens', 59),
(16, 'Day-Date', '48500', 'L’Oyster Perpetual Day-Date 36 en or Everose 18 ct dotée d’un cadran blanc, d’une lunette cannelée et d’un bracelet President.', 'L’accomplissement d’un idéal', 120),
(17, 'Cosmograph Daytona', '97600', 'Cette Oyster Perpetual Cosmograph Daytona en platine assortie d’un cadran bleu glacier et d’un bracelet Oyster est dotée d’une lunette Cerachrom marron et d’une échelle tachymétrique.', 'Le triomphe de l’endurance', 95),
(18, 'oyster', '7350', 'L’Oyster Perpetual 34 dotée d’un cadran argenté et d’un bracelet Oyster.', 'Un monde à soi', 512),
(19, 'Yacht-Master', '15350', 'L’Oyster Perpetual Yacht-Master 40 en acier Oystersteel et platine est assortie d’un bracelet Oyster.', 'Suivre son cap', 156),
(20, 'Sea-Dweller', '23300', 'L’Oyster Perpetual Sea-Dweller en acier Oystersteel et or jaune est dotée d’un disque de lunette Cerachrom en céramique noire et d’un bracelet Oyster.', 'Citoyenne des profondeurs', 120),
(21, 'Sky-Dweller', '20200', 'L’Oyster Perpetual Sky-Dweller en acier Oystersteel et or gris est dotée d’un cadran vert menthe et d’un bracelet Jubilee.', 'De haut vol', 59);

-- --------------------------------------------------------

--
-- Structure de la table `watchcommande`
--

CREATE TABLE `watchcommande` (
  `id_watch` int(11) DEFAULT NULL,
  `id_commande` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `watchcommande`
--

INSERT INTO `watchcommande` (`id_watch`, `id_commande`, `quantite`) VALUES
(13, NULL, 1),
(13, NULL, 1),
(16, NULL, 1),
(20, NULL, 5),
(15, NULL, 4),
(18, NULL, 2),
(12, NULL, 1),
(16, NULL, 5),
(17, NULL, 1),
(13, NULL, 1),
(19, NULL, 1),
(12, NULL, 1),
(20, NULL, 1),
(12, NULL, 1),
(13, NULL, 1),
(12, NULL, 1),
(17, NULL, 1),
(12, 90, 1),
(13, 91, 7),
(18, 91, 5),
(12, 92, 7),
(17, 92, 1),
(16, 92, 1),
(16, 93, 1),
(20, 93, 1),
(15, 93, 1);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `adresse`
--
ALTER TABLE `adresse`
  ADD PRIMARY KEY (`id_adresse`);

--
-- Index pour la table `adresseutilisateur`
--
ALTER TABLE `adresseutilisateur`
  ADD KEY `fk_adresse_utilisateur` (`id_adresse`),
  ADD KEY `fk_utilisateur_adresse` (`id_utilisateur`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id_commande`),
  ADD KEY `fk_commande_utilisateur` (`id_utilisateur`);

--
-- Index pour la table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id_image`),
  ADD KEY `fk_image_watch` (`id_watch`);

--
-- Index pour la table `marque`
--
ALTER TABLE `marque`
  ADD PRIMARY KEY (`id_marque`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id_role`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id_utilisateur`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_role_utilisateur` (`id_role`);

--
-- Index pour la table `watch`
--
ALTER TABLE `watch`
  ADD PRIMARY KEY (`id_watch`);

--
-- Index pour la table `watchcommande`
--
ALTER TABLE `watchcommande`
  ADD KEY `fk_watch_commande` (`id_watch`),
  ADD KEY `fk_commande_watch` (`id_commande`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `adresse`
--
ALTER TABLE `adresse`
  MODIFY `id_adresse` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `id_commande` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT pour la table `image`
--
ALTER TABLE `image`
  MODIFY `id_image` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `marque`
--
ALTER TABLE `marque`
  MODIFY `id_marque` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `role`
--
ALTER TABLE `role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id_utilisateur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `watch`
--
ALTER TABLE `watch`
  MODIFY `id_watch` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `adresseutilisateur`
--
ALTER TABLE `adresseutilisateur`
  ADD CONSTRAINT `fk_adresse_utilisateur` FOREIGN KEY (`id_adresse`) REFERENCES `adresse` (`id_adresse`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_utilisateur_adresse` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id_utilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `fk_commande_utilisateur` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id_utilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `fk_image_watch` FOREIGN KEY (`id_watch`) REFERENCES `watch` (`id_watch`);

--
-- Contraintes pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `fk_role_utilisateur` FOREIGN KEY (`id_role`) REFERENCES `role` (`id_role`);

--
-- Contraintes pour la table `watchcommande`
--
ALTER TABLE `watchcommande`
  ADD CONSTRAINT `fk_commande_watch` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`),
  ADD CONSTRAINT `fk_watch_commande` FOREIGN KEY (`id_watch`) REFERENCES `watch` (`id_watch`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
