<?php
include "./includes/fonction.php";
include "./public/header.php";

$watchs = getAllPanier();

$prix_total = 0;
$quantite = 0;
$mode_paiement = 'PayPal';

foreach ($watchs as $product) {
    $quantity = $product[0];
    $watch = $product[1];
    $price = $watch["prix"];
    $prix_total += $price * $quantity;
    $quantite += $quantity;
    $date_creation = date('Y-m-d');

}
echo $id_utilisateur = $_SESSION['Utilisateur']['id_utilisateur'] . "<br>";
echo $prix_total . "<br>";
echo $quantite . "<br>";
echo $date_creation . "<br>";

$id_commande=insertPayment($id_utilisateur, $quantite, $prix_total, $mode_paiement);

foreach ($watchs as $product) {
    $quantite = $product[0];
    $watch = $product[1];
    $id_watch = $watch['id_watch'];
    insertWatchCommande($id_watch, $id_commande, $quantite);
}

unset($_SESSION['Paniers']); 

header("Location: payment.php");
exit;

?>

