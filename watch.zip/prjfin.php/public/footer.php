<footer class="footer py-4 green-background"style="background: rgb(179,103,0);
background: radial-gradient(circle, rgba(179,103,0,1) 0%, rgba(167,103,17,1) 44%, rgba(145,102,42,1) 100%);" >
    
      <div class="row">
        <div class="col-md-2">
        <i class="bi bi-box-arrow-in-right"></i>
          <a class="text-white" href="./login.php">Connexion</a>
        </div>
        <div class="col-md-2">
        <i class="bi bi-geo-alt"></i>
          <a class="text-white" href="http://maps">Ville</a>
        </div>
        <div class="col-md-2">
        <i class="bi bi-file-earmark-person"></i>
          <a class="text-white" href="./about.php">À Propos</a>
        </div>
        <div class="col-md-4">
          <div class="icon-rese">
            <a href="https://www.facebook.com/"><i class="bi bi-facebook"></i></a>
            <a href="https://www.instagram.com/"><i class="bi bi-instagram"></i></a>
            <a href="https://twitter.com/"><i class="bi bi-twitter-x"></i></a>
            <a href="https://www.youtube.com/"><i class="bi bi-youtube"></i></a>
          </div>
        </div>
      </div>
      <br/>
      <div class="row mt-3  text-white">
        <div class="col-md-4">
          <p>CONDITIONS D’UTILISATION</p>
          <p>POLITIQUE DE CONFIDENTIALITÉ</p>
          <p>Politique cookies</p>
        </div>
        <div class="col-md-4">
          <p>Affilier</p>
          <p>DÉCLARATION D’ACCESSIBILITÉ</p>
        </div>
        <div class="col-md-4">
          <p>Activate</p>
          <p>Nous Trouver</p>
          <p>reservation</p>
        </div>
      </div>
      <div class="row mt-3">
        <div class="col-md-12">
          <p class="text-center text-white">© MyWatch.ll rights reserved. Developed By Red-Bomb.</p>
        </div>
      </div>
    </div>
  </footer>
</body>
</html>