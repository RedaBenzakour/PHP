<nav class="navbar navbar-expand-lg bg-body-tertiary mb-5" style="background: rgb(179,103,0);
background: radial-gradient(circle, rgba(179,103,0,1) 0%, rgba(167,103,17,1) 44%, rgba(145,102,42,1) 100%);">
    <div class="container-fluid">
        <a class="navbar-brand" href="./about.php"><img src="./assets/MonLogo.png" style="width: 50px; height: 50px;"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="./index.php">Home</a>
                </li>
                <?php if (!isset($_SESSION['Utilisateur'])): ?>
                    <li class="nav-item"><a class="nav-link" href="./login.php">Connexion</a></li>
                    <li class="nav-item"><a class="nav-link" href="./register.php">Inscription</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="btn btn-danger" href="./deconnexion.php">Deconnexion</a></li>
                <?php endif; ?>
                <?php if (isset($_SESSION['Utilisateur'])): ?>
                    <li class="nav-item">
                        <a href="./panier.php" class="btn" aria-disabled="true"><i class="bi bi-cart4">
                            <?php echo (isset($_SESSION['Paniers'])) ? count($_SESSION['Paniers']) : 0; ?>
                        </i></a>
                    </li>
                    <li class="nav-item">
                        <a class="btn " href="./profil.php"><i class="bi bi-person-circle"></i> </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
