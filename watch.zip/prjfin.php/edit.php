

<?php

include "includes/fonction.php";
include "public/header.php";


// Check if the user is logged in
if (!isset($_SESSION['Utilisateur'])) {
    header("Location: login.php");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form data
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $role = $_POST['role'];
    $email = $_POST['email'];
    $telephone = $_POST['telephone'];
    $date_naissance = $_POST['date_naissance'];
    
    // Call the update function
    if (updateProfile($_SESSION['Utilisateur']['id_utilisateur'], $nom, $prenom, $email, $telephone, $date_naissance)) {
        // Redirect to profile page after successful update
        header("Location: profil.php");
        exit();
    } else {
        echo "Failed to update profile.";
    }
}

?>

<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    padding: 20px;
}

form {
    max-width: 400px;
    margin: 0 auto;
    background: #fff;
    padding: 30px;
    border-radius: 5px;
    box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
}

label {
    font-weight: bold;
}

input[type="text"],
input[type="email"],
input[type="date"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 3px;
    cursor: pointer;
    font-size: 16px;
}

input[type="submit"]:hover {
    background-color: #45a049;
}

</style>
<form method="post">
    <label for="nom">Nom:</label><br>
    <input type="text" id="nom" name="nom" value="<?php echo $_SESSION['Utilisateur']['nom']; ?>"><br>
    <label for="prenom">Prénom:</label><br>
    <input type="text" id="prenom" name="prenom" value="<?php echo $_SESSION['Utilisateur']['prenom']; ?>"><br>
    <?php
    if ($_SESSION['Utilisateur']['id_role'] == 1) {
        ?>
    <label for="role">role:(1=admin , 2=user)</label><br>
    <input type="text" id="role" name="role" value="<?php echo $_SESSION['Utilisateur']['id_role']; ?>"><br>
    <?php
    }
    ?>
    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email" value="<?php echo $_SESSION['Utilisateur']['email']; ?>"><br>
    <label for="telephone">Téléphone:</label><br>
    <input type="text" id="telephone" name="telephone" value="<?php echo $_SESSION['Utilisateur']['telephone']; ?>"><br>
    <label for="date_naissance">Date de naissance:</label><br>
    <input type="date" id="date_naissance" name="date_naissance" value="<?php echo $_SESSION['Utilisateur']['date_naissance']; ?>"><br><br>
    <input type="submit" value="Enregistrer">
</form>
