<?php
include "includes/fonction.php";

/*if (!isset($_SESSION['Utilisateur']) ||
    $_SESSION['Utilisateur']['description'] !== 'admin') {
    header("Location: index.php");

    }else {*/
    include "public/header.php";

    if (isset($_POST['creeProduit'])) {

        //upload();

        if (estValid($_POST)) {

            $nom = $_POST['nom'];
            $prix = $_POST['prix'];
            $description = $_POST['description'];
            $courte_description = $_POST['courte_description'];
            $quantite = $_POST['quantite'];

            addProduit($nom, $prix, $quantite, $description, $courte_description);
        }

    }
//}
?>
    <body class="container  " style="background-image: url('assets/footerWatch.jpg');">
    <form method="post" enctype="multipart/form-data">
    <div class="card" style="background: rgb(63,112,67);
background: linear-gradient(0deg, rgba(63,112,67,1) 34%, rgba(42,63,46,1) 100%);">
        <div class="mb-3">
            <label for="nom" class="form-label">Nom produit :</label>
            <input type="text" class="form-control" id="nom" name="nom">
        </div>

        <div class="mb-3">
            <label for="prix" class="form-label">Prix :</label>
            <input type="number" class="form-control" id="prix" name="prix">
        </div>

        <div class="mb-3">
            <label for="quantite" class="form-label">Quantite :</label>
            <input type="number" class="form-control" id="quantite" name="quantite">
        </div>

        <div class="mb-3">
            <input type="file" name="image">
        </div>

        <div class="form-floating mb-3">
            <textarea class="form-control" name="description" placeholder="ajouter une description"
                      id="description"></textarea>
            <label for="description">Description </label>
        </div>

        <div class="form-floating mb-3">
            <textarea class="form-control" name="courte_description" placeholder="ajouter une description"
                      id="courte_description"></textarea>
            <label for="courte_description">Courte description </label>
        </div>
        <input type="submit" class="btn btn-primary" id="creeProduit" name="creeProduit" value="Ajouter produit">
</div>
    </form>
    <br/>
    <br/>

<?php
include "public/footer.php";
?>