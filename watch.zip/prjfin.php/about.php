<?php
include "includes/fonction.php";
include "public/header.php";


?>
<style>
* {
  box-sizing: border-box;
}


body {
  font-family: Arial;
  padding: 20px;
  background: #f1f1f1;
}


/* Header/Blog Title */
.header {
  padding: 30px;
  font-size: 40px;
  text-align: center;
  background: white;
}

/* Create two unequal columns that floats next to each other */
/* Left column */
.leftcolumn {
  float: left;
  width: 75%;
}

/* Right column */
.rightcolumn {
  float: left;
  width: 25%;
  padding-left: 20px;
}

/* Fake image */
.fakeimg {
    background-image: url('https://krono.hu/uploads/images/articles/svajci-orak-1_1.jpg');
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}
.fakeimg2 {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}
.fakeimg1 {
    background-image: url('./assets/presonelle/image.png');

}

/* Add a card effect for articles */
.card {
  background-color: white;
  padding: 20px;
  margin-top: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}


.card img {
  max-height: 200px; /* ajustez cette valeur selon vos besoins */
  width: auto;
  display: block;
  margin: 0 auto;
}


/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 800px) {
  .leftcolumn, .rightcolumn {
    width: 100%;
    padding: 0;
  }
}


</style>
<div class="header">
  <h2>My Watch</h2>
</div>

<div class="row">
  <div class="leftcolumn">
    <div class="card">
      <h2>A propos</h2>
      <h5>date de creation : 01-04-2024</h5>
      <div class="fakeimg" style="height:200px;">
    </div>
    </div>
    <div class="card">
      <h2>Information sur le Web</h2>
      <p>
      MyWatch incarne l'essence intemporelle de l'élégance horlogère, fusionnant habilement l'artisanat traditionnel avec l'innovation contemporaine.
       Chaque montre est une symphonie de précision mécanique et de design raffiné, capturant l'esprit de ceux qui valorisent le temps comme leur bien le plus précieux.
        Nos garde-temps sont bien plus que de simples accessoires ; ce sont des compagnons de vie qui transcendent les modes éphémères pour devenir des héritages inestimables.
       Avec une attention méticuleuse portée aux détails et une passion infinie pour l'excellence, MyWatch incarne l'art de l'horlogerie luxueuse, élevant chaque instant à une expérience d'exception.
      </p>
    </div>
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>Createur: Reda Benzakour</h2>
      <div class="fakeimg1" ></div>
      <img src="./assets/presonelle/imageR.png"></div>

    <div class="card">
      <h2>Createur: Ayoub  Benouar </h2>
      <div class="fakeimg1"></div>
      <img src="./assets/presonelle/image.png"></div>
    </div>
    <div class="card">
      <h3>details du projet </h3>
      <div class="fakeimg2"> les taches faites par ayoub : profil / about / payment / suive</div><br>
      <div class="fakeimg2">les taches faites par reda: login-register / index / panier /commande </div><br>
      <div class="fakeimg2">cette page a pour objectif a clarifier les taches faites par chaque programeur le css est le html n'est pas prix en quante</div>
    </div>

    </div>
  </div>
</div>


<?php
include "./public/footer.php";
?>
</body>
</html>