<?php
include "./includes/fonction.php";
include "./public/header.php";

$watchs = getAllPanier();

$totalPrice = 0;
$totalQuantity = 0;
foreach ($watchs as $product) {
    $quantity = $product[0];
    $watch = $product[1];
    $price = $watch["prix"];
    $totalPrice += $price * $quantity;
    $totalQuantity += $quantity;
}

 $_SESSION['totalPrice'] = $totalPrice;
 $_SESSION['totalQuantity'] = $totalQuantity;


if (isset($_POST['payment'])) {

    header("Location: commandes.php");

}

?>
<style>
    .btn.btn-primary.payment {
    background-color: #1c6acf;
    color: white;
    border-radius: 0px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 24px;
}4
</style>
<table class="table">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Nom</th>
        <th scope="col">Prix</th>
        <th scope="col">description</th>
        <th scope="col">Quantite</th>
        <th scope="col">Image</th>
        <th scope="col">Actions</th>

    </tr>
    </thead>
    <tbody>
    <?php
    $cmp = 1;
    foreach ($watchs as $ligneWatch) {
        $quantite = $ligneWatch[0];
        $watch = $ligneWatch[1];
        ?>
        <form action="miseAJour.php?id=<?php echo $watch['id_watch']; ?>" method="post">
            <tr>
                <th scope="row"><?php echo $cmp++; ?></th>
                <td><?php echo $watch["nom"]; ?></td>
                <td><?php echo $watch["prix"]; ?></td>
                <td><?php echo $watch["courte_description"]; ?></td>
                <td><input name="quantite" type="number" min="1" max="<?php echo $watch["quantite"]; ?>"
                           value="<?php echo $quantite; ?>">
                </td>
                <td>
                    <img width="200px"  height="200px" src="<?=
                    (isset($watch["chemin_image"]) && !empty($watch["chemin_image"])) ?
                        $watch["chemin_image"] :
                        "./assets/image.jpg";
                    ?>" alt="...">
                </td>
                <td style="display: flex; flex-direction: column; align-items: center;">
                     <div style="margin-bottom: 5px;">
                      <button type="submit" class="btn btn-primary">Modifier</button>
                    </div>
                     <div>
                    <a class="btn btn-danger" href="supprimerPanier.php?id=<?php echo $watch['id_watch']; ?>">Supprimer</a>
                     </div>
                     <div><br/<br/><br/><br/><br/></div>
                     
                </td>

            </tr>
            <!-- Change button type to submit -->

        </form>
        

        <?php
    }
    ?>
    </tbody>

</table>

<div class="container">
    <div class="row">
        <div class="col-12">
            <form  method="post">
                <input type="submit" class="btn btn-primary" id="payment" name="payment" value="Payment">
            </form>
        </div>
    </div>

    <h1>Shopping Cart</h1>

    <form action="modifier_quantite.php" method="POST">
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Suppose $products is an array containing product details retrieved from the database
                $products = getAllPanier();
                $totalPrice = 0;
                $totalQuantity = 0;
                foreach ($products as $product) {
                    $quantity = $product[0];
                    $watch = $product[1];
                    $price = $watch["prix"];
                    $totalPrice += $price * $quantity;
                    $totalQuantity += $quantity;
                ?>
                <tr>
                    <td><?php echo $watch["nom"]; ?></td>
                    <td><?php echo $price; ?></td>
                    <td>
                    <input type="number" name="quantity_<?php echo $watch['id_watch']; ?>" min="1" value="<?php echo $quantity; ?>">
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <p class="font-weight-bold">Total Price: <?php echo $totalPrice; ?></p>
        <p class="font-weight-bold">Total Quantity: <?php echo $totalQuantity; ?></p>
        <!-- Ajoutez ici un bouton pour modifier la quantité ou supprimer des éléments du panier si nécessaire -->
    </form>
</div>






<?php
include "./public/footer.php";
?>